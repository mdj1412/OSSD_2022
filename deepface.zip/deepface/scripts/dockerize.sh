docker build -t deepface_image .

docker run -it deepface_image /bin/sh